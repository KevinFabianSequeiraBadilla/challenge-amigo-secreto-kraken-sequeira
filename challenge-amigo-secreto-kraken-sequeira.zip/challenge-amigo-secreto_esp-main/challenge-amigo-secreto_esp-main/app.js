// El principal objetivo de este desafío es fortalecer tus habilidades en lógica de programación. Aquí deberás desarrollar la lógica para resolver el problema.
// Array para almacenar los nombres

//arreglo a usar
let amigos = [];

// Función para añadir amigos a la lista
function agregarAmigo() {
  const input = document.getElementById('amigo');
  const nombre = input.value.trim();

  if (nombre !== '') {
    amigos.push(nombre);
    mostrarListaAmigos();
    input.value = '';
  } else {
    alert('Por favor, ingresa un nombre');
  }
}

// Función que actualiza la lista visible en pantalla
function mostrarListaAmigos() {
  const lista = document.getElementById('listaAmigos');
  lista.innerHTML = '';

  amigos.forEach((amigo) => {
    const li = document.createElement('li');
    li.textContent = amigo;
    lista.appendChild(li);
  });
}

// Función para sortear un amigo al azar
function sortearAmigo() {
  // Si no hay amigos, avisar
  if (amigos.length === 0) {
    alert('No hay amigos en la lista para sortear.');
    return;
  }

  // Elegir un índice aleatorio
  const indiceAleatorio = Math.floor(Math.random() * amigos.length);
  const amigoSorteado = amigos[indiceAleatorio];

  // Mostrar el resultado
  const resultado = document.getElementById('resultado');
  resultado.innerHTML = ''; // Limpia cualquier resultado previo

  // Crear un elemento que muestre el nombre sorteado
  const liResultado = document.createElement('li');
  liResultado.textContent = `El amigo sorteado es: ${amigoSorteado}`;
  resultado.appendChild(liResultado);

  // Crear el botón "Continuar"
  const btnContinuar = document.createElement('button');
  btnContinuar.textContent = 'Continuar';
  btnContinuar.onclick = function () {
    // 1. Eliminar el amigo sorteado del array
    amigos.splice(indiceAleatorio, 1);

    // 2. Volver a mostrar la lista sin el amigo eliminado
    mostrarListaAmigos();

    // 3. Limpiar el resultado para el siguiente sorteo
    resultado.innerHTML = '';
  };

  // Agregar el botón "Continuar" al resultado
  resultado.appendChild(btnContinuar);
}
